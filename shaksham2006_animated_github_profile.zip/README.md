<div align="center">

<h3><code>shaksham@github ~ $ ./contributions.sh</code></h3>

<img src="./contrib-heatmap.svg" width="860" alt="Animated GitHub contribution heatmap"/>

<br><br>

<h3><code>shaksham@github ~ $ whoami</code></h3>

<table>
<tr>
<td valign="top"><img src="./avi-ascii.svg" width="370" alt="Animated ASCII portrait"/></td>
<td valign="top"><img src="./info-card.svg" width="490" alt="Terminal-style developer information card"/></td>
</tr>
</table>

<br>

<a href="https://www.linkedin.com/in/shaksham-verma-93a517389/">LinkedIn</a>
&nbsp;•&nbsp;
<a href="https://leetcode.com/u/shaksham_verma_18/">LeetCode</a>
&nbsp;•&nbsp;
<a href="mailto:shakshamkverma@gmail.com">Email</a>

</div>
